// Əlaqə forması (contact.html)
// ================= CONTACT FORM =================
function handleContactSubmit(e) {
    e.preventDefault();
    const f = e.target;
    const name = f.elements[0].value, email = f.elements[1].value, topic = f.elements[2].value, msg = f.elements[3].value;
    const body = `Ad: ${name}\nE-poçt: ${email}\n\n${msg}`;
    window.location.href = `mailto:info@cografiya.org?subject=${encodeURIComponent(topic)}&body=${encodeURIComponent(body)}`;
    document.getElementById('contact-success').textContent = '✓ E-poçt proqramınız açıldı. Mesajı orada göndərməyi unutmayın.';
    document.getElementById('contact-success').classList.remove('hidden');
}
