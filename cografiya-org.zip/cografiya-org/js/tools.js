// Kalkulyatorlar və region faktları (tools.html)
// ================= CALCULATORS LOGIC =================
function calculateScale() {
    const scale = parseFloat(document.getElementById('scale-input').value);
    const distCm = parseFloat(document.getElementById('map-dist-input').value);

    if (isNaN(scale) || isNaN(distCm) || scale <= 0 || distCm <= 0) {
        document.getElementById('scale-result-val').innerText = "Məlumatı düzgün daxil edin";
        return;
    }

    const realKm = (distCm * scale) / 100000;
    document.getElementById('scale-result-val').innerText = `${realKm.toLocaleString('az-AZ', { maximumFractionDigits: 3 })} km`;
}

function calculateMeridianTime() {
    const out = document.getElementById('time-result-val');
    const m1 = parseFloat(document.getElementById('meridian1-input').value);
    const m2 = parseFloat(document.getElementById('meridian2-input').value);
    if (isNaN(m1) || isNaN(m2) || m1 < 0 || m1 > 180 || m2 < 0 || m2 > 180) {
        out.textContent = "0° - 180° daxil edin";
        return;
    }
    const p1 = document.getElementById('dir1-input').value === 'E' ? m1 : -m1;
    const p2 = document.getElementById('dir2-input').value === 'E' ? m2 : -m2;

    let diffDeg = Math.abs(p1 - p2);
    if (diffDeg > 180) diffDeg = 360 - diffDeg; // ən qısa qövs

    const totalSec = Math.round(diffDeg * 240); // 1° = 4 dəq = 240 san
    const h = Math.floor(totalSec / 3600);
    const mi = Math.floor((totalSec % 3600) / 60);
    const sc = totalSec % 60;
    out.textContent = `${h} saat ${mi} dəq${sc ? ' ' + sc + ' san' : ''} (${+diffDeg.toFixed(2)}°)`;
}

function calculateAzimuth() {
    const deg = parseFloat(document.getElementById('azimuth-input').value);
    if (isNaN(deg) || deg < 0 || deg > 360) {
        document.getElementById('azimuth-result-val').innerText = "0° - 360° daxil edin";
        return;
    }

    let direction = "";
    if (deg === 0 || deg === 360) direction = "Şimal (N)";
    else if (deg > 0 && deg < 90) direction = "Şimal-Şərq (NE)";
    else if (deg === 90) direction = "Şərq (E)";
    else if (deg > 90 && deg < 180) direction = "Cənub-Şərq (SE)";
    else if (deg === 180) direction = "Cənub (S)";
    else if (deg > 180 && deg < 270) direction = "Cənub-Qərb (SW)";
    else if (deg === 270) direction = "Qərb (W)";
    else if (deg > 270 && deg < 360) direction = "Şimal-Qərb (NW)";

    document.getElementById('azimuth-result-val').innerText = direction;
}

// ================= REGION FACTS MAP =================
const regionFacts = [
    { name: "Abşeron-Xızı", desc: "Ölkənin ən böyük sənaye və şəhər aqlomerasiyasıdır. Kimya, neft-qaz emalı və maşınqayırma inkişaf etmişdir.", spec: "Neft-Kimya, Xidmət", city: "Sumqayıt, Xırdalan" },
    { name: "Qarabağ", desc: "Zəngin su ehtiyatlarına, tikinti materiallarına və aqrar potensiala malikdir. Bərpa olunan enerji layihələri həyata keçirilir.", spec: "Kənd Təsərrüfatı, Enerji", city: "Xankəndi, Şuşa, Ağdam" },
    { name: "Şərqi Zəngəzur", desc: "Qızıl, civə və mineral su ehtiyatları (İstisu) ilə seçilir. Zəngəzur dəhlizi mühüm loqistik əhəmiyyət daşıyır.", spec: "Dağ-Mədən, Turizm", city: "Laçın, Kəlbəcər, Zəngilan" },
    { name: "Lənkəran-Astara", desc: "Rütubətli subtropik iqlimə malikdir. Çayçılıq, çəltikçilik, sitrus meyvəçiliyi üzrə ixtisaslaşmışdır.", spec: "Sitrus, Çayçılıq, Turizm", city: "Lənkəran, Astara" },
    { name: "Naxçıvan", desc: "Kəskin kontinental iqlimi, mərmər, duz yataqları və Sirab, Badamlı mineral suları ilə tanınır.", spec: "Mədən, Subtropik Meyvə", city: "Naxçıvan, Julfa" }
];

function initRegionFacts() {
    const btnContainer = document.getElementById('region-fact-buttons');
    if (!btnContainer) return;
    btnContainer.innerHTML = '';

    regionFacts.forEach((reg, idx) => {
        const btn = document.createElement('button');
        btn.className = `px-3 py-2 text-xs font-bold rounded-xl border border-slate-700 transition ${idx === 0 ? 'bg-geo-600 text-white border-geo-500' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`;
        btn.innerText = reg.name;
        btn.onclick = (e) => {
            document.querySelectorAll('#region-fact-buttons button').forEach(b => b.className = "px-3 py-2 text-xs font-bold rounded-xl border border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-700");
            e.target.className = "px-3 py-2 text-xs font-bold rounded-xl border border-geo-500 bg-geo-600 text-white";
            
            document.getElementById('fact-region-title').innerText = reg.name + " İqtisadi Rayonu";
            document.getElementById('fact-region-desc').innerText = reg.desc;
            document.getElementById('fact-region-stats').innerHTML = `
                <div><span class="text-slate-400">İxtisaslaşma:</span> <span class="font-bold text-white">${reg.spec}</span></div>
                <div><span class="text-slate-400">Əsas Şəhərlər:</span> <span class="font-bold text-white">${reg.city}</span></div>
            `;
        };
        btnContainer.appendChild(btn);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    if (!document.getElementById('scale-input')) return;
    ['scale-input', 'map-dist-input'].forEach(id => document.getElementById(id).addEventListener('input', calculateScale));
    ['meridian1-input', 'dir1-input', 'meridian2-input', 'dir2-input'].forEach(id => document.getElementById(id).addEventListener('input', calculateMeridianTime));
    document.getElementById('azimuth-input').addEventListener('input', calculateAzimuth);
    calculateScale(); calculateMeridianTime(); calculateAzimuth();
    initRegionFacts();
});
