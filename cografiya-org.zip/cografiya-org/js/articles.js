// Məqalə axtarışı (articles.html)
// ================= SEARCH ARTICLES =================
function searchArticles() {
    const query = document.getElementById('articles-search').value.trim().toLocaleLowerCase('az');
    const cards = document.querySelectorAll('.article-card');
    let visible = 0;
    cards.forEach(card => {
        const match = card.innerText.toLocaleLowerCase('az').includes(query);
        card.style.display = match ? "flex" : "none";
        if (match) visible++;
    });
    let empty = document.getElementById('articles-empty');
    if (!empty) {
        empty = document.createElement('p');
        empty.id = 'articles-empty';
        empty.className = 'hidden text-center text-sm text-slate-500 py-12';
        empty.textContent = 'Heç bir məqalə tapılmadı. Başqa açar söz yoxlayın.';
        document.getElementById('articles-grid').after(empty);
    }
    empty.classList.toggle('hidden', visible > 0);
}

document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('articles-search');
    if (input) input.addEventListener('input', searchArticles);
});
