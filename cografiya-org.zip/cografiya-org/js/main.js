// Coğrafiya.org - bütün səhifələr üçün ümumi skript
document.addEventListener('DOMContentLoaded', () => {
    if (window.lucide) lucide.createIcons();

    // Mobil menyu
    const btn = document.getElementById('mobile-menu-btn');
    const menu = document.getElementById('mobile-menu');
    if (btn && menu) {
        btn.addEventListener('click', () => {
            menu.classList.toggle('hidden');
            btn.setAttribute('aria-expanded', String(!menu.classList.contains('hidden')));
        });
    }

    // Modal: Esc və kənara klik ilə bağlanır
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
    const modal = document.getElementById('global-modal');
    if (modal) modal.addEventListener('click', e => { if (e.target.id === 'global-modal') closeModal(); });
});

// ================= GLOBAL MODAL VIEW =================
function openModal(title, text) {
    document.getElementById('modal-title').innerText = title;
    document.getElementById('modal-body').innerText = text;
    const modal = document.getElementById('global-modal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeModal() {
    const modal = document.getElementById('global-modal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}
