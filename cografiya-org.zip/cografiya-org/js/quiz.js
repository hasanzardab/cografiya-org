// Sınaq imtahanları mühərriki (quizzes.html)
// ================= QUIZ ENGINE LOGIC =================
const quizDatabase = [
    {
        q: "Azərbaycan Respublikasının ən yüksək zirvəsi Bazardüzü (4466 m) hansı silsilədə yerləşir?",
        cat: "azərbaycan",
        opts: ["Baş Qafqaz silsiləsi", "Şahdağ silsiləsi", "Murovdağ silsiləsi", "Zəngəzur silsiləsi"],
        ans: 0,
        exp: "Bazardüzü zirvəsi Baş Qafqaz silsiləsində yerləşir."
    },
    {
        q: "İzohips (horizontal) xətləri sıxlaşdıqca ərazidə NƏ müşahidə olunur?",
        cat: "fiziki",
        opts: ["Meyillilik artır", "Meyillilik azalır", "Temperatur artır", "Buxarlanma azalır"],
        ans: 0,
        exp: "Xəritədə horizontalların sıx olması dikliyin və meyilliliyin yüksək olduğunu bildirir."
    },
    {
        q: "Azərbaycanın hansı iqtisadi rayonu ən böyük pambıqçılıq bazasına malikdir?",
        cat: "iqtisadi",
        opts: ["Mil-Muğan", "Abşeron-Xızı", "Quba-Xaçmaz", "Lənkəran-Astara"],
        ans: 0,
        exp: "Mil-Muğan və Mərkəzi Aran iqtisadi rayonları pambıqçılıq üzrə ixtisaslaşmışdır."
    },
    {
        q: "Dünyanın ən sahəcə böyük adası hansıdır?",
        cat: "fiziki",
        opts: ["Madaqaskar", "Qrenlandiya", "Kalimantan", "Sumatra"],
        ans: 1,
        exp: "Qrenlandiya adası 2.16 milyon km² sahəyə malikdir."
    },
    {
        q: "Xəzər dənizinin səviyyəsi dünya okeanı səviyyəsindən neçə metr aşağıdadır?",
        cat: "azərbaycan",
        opts: ["-27 m", "-10 m", "-100 m", "-5 m"],
        ans: 0,
        exp: "Xəzər dənizinin orta səviyyəsi təqribən -27 metr təşkil edir."
    },
    { q: "Azərbaycanın ən uzun çayı hansıdır?", cat: "azərbaycan", opts: ["Kür", "Araz", "Qanıx", "Samur"], ans: 0, exp: "Kür Cənubi Qafqazın ən uzun çayıdır; Azərbaycan ərazisində təxminən 906 km axır." },
    { q: "Azərbaycanın ən böyük gölü hansıdır?", cat: "azərbaycan", opts: ["Sarısu", "Göygöl", "Maralgöl", "Ağgöl"], ans: 0, exp: "Sarısu gölü sahəsinə görə ölkənin ən böyük gölüdür." },
    { q: "Naxçıvan Muxtar Respublikasının ən yüksək zirvəsi hansıdır?", cat: "azərbaycan", opts: ["Qapıcıq", "Tufandağ", "Şahdağ", "Bazardüzü"], ans: 0, exp: "Qapıcıq zirvəsinin hündürlüyü 3904 m-dir." },
    { q: "2021-ci il islahatından sonra Azərbaycanda neçə iqtisadi rayon var?", cat: "iqtisadi", opts: ["10", "14", "11", "7"], ans: 1, exp: "Azərbaycan ərazisi 14 iqtisadi rayona bölünür." },
    { q: "Başlanğıc (0°) meridian hansı məntəqədən keçir?", cat: "fiziki", opts: ["Qrinviç", "Paris", "Moskva", "Nyu-York"], ans: 0, exp: "Başlanğıc meridian Londonun Qrinviç rayonundan keçir." },
    { q: "Dünyanın ən dərin gölü hansıdır?", cat: "fiziki", opts: ["Baykal", "Viktoriya", "Superior", "Tanqanika"], ans: 0, exp: "Baykalın maksimal dərinliyi təxminən 1642 m-dir." },
    { q: "Hər saat qurşağı neçə dərəcə uzunluğu əhatə edir?", cat: "fiziki", opts: ["10°", "15°", "30°", "4°"], ans: 1, exp: "Yer 24 saat qurşağına bölünür: 360° / 24 = 15°. 1° isə 4 dəqiqəyə bərabərdir." }
];

let activeQuizList = [...quizDatabase];
let currentQIdx = 0;
let quizScore = 0;
let selectedAnswers = [];

function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

function filterQuizCategory(cat) {
    document.querySelectorAll('.quiz-cat-btn').forEach(btn => {
        const active = btn.getAttribute('onclick').includes(`'${cat}'`);
        btn.className = "quiz-cat-btn px-4 py-2 text-xs font-bold rounded-xl " + (active ? "bg-geo-600 text-white shadow-md" : "bg-slate-800 text-slate-300 hover:bg-slate-700");
        btn.setAttribute('aria-pressed', active);
    });
    activeQuizList = cat === 'all' ? [...quizDatabase] : quizDatabase.filter(q => q.cat === cat);
    resetQuiz();
}

function quizCorrectCount() {
    return selectedAnswers.reduce((n, a, i) => n + (activeQuizList[i] && a === activeQuizList[i].ans ? 1 : 0), 0);
}

function loadQuizQuestion() {
    if (activeQuizList.length === 0) return;
    const q = activeQuizList[currentQIdx];
    const picked = selectedAnswers[currentQIdx];
    const locked = picked !== undefined;
    const isLast = currentQIdx === activeQuizList.length - 1;

    document.getElementById('quiz-question').textContent = `${currentQIdx + 1}. ${q.q}`;
    document.getElementById('quiz-counter').textContent = `Sual ${currentQIdx + 1} / ${activeQuizList.length}`;
    document.getElementById('quiz-score').textContent = `Xal: ${quizCorrectCount()}`;
    document.getElementById('quiz-progress').style.width = `${((currentQIdx + 1) / activeQuizList.length) * 100}%`;
    document.getElementById('quiz-next-btn').textContent = isLast ? 'Nəticəni Gör' : 'Növbəti Sual';

    const optsDiv = document.getElementById('quiz-options');
    optsDiv.innerHTML = '';
    q.opts.forEach((opt, idx) => {
        let state = 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700', mark = '';
        if (locked) {
            if (idx === q.ans) { state = 'border-emerald-500 bg-emerald-950/60 text-emerald-300'; mark = '✓'; }
            else if (idx === picked) { state = 'border-rose-500 bg-rose-950/60 text-rose-300'; mark = '✕'; }
            else state = 'border-slate-800 bg-slate-800/40 text-slate-500';
        }
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.disabled = locked;
        btn.className = `w-full text-left p-4 rounded-xl border text-xs sm:text-sm font-semibold transition flex items-center justify-between ${state}`;
        const label = document.createElement('span');
        label.textContent = `${String.fromCharCode(65 + idx)}) ${opt}`;
        const m = document.createElement('span');
        m.textContent = mark;
        btn.append(label, m);
        btn.onclick = () => selectQuizAnswer(idx);
        optsDiv.appendChild(btn);
    });

    const fb = document.getElementById('quiz-feedback');
    if (locked) {
        const ok = picked === q.ans;
        fb.className = "p-4 rounded-xl mb-6 text-xs sm:text-sm font-semibold border " + (ok ? "bg-emerald-950/80 border-emerald-500/50 text-emerald-300" : "bg-rose-950/80 border-rose-500/50 text-rose-300");
        fb.textContent = (ok ? '✓ Doğru cavab! ' : `✕ Yanlış cavab. Doğru cavab: ${q.opts[q.ans]}. `) + q.exp;
    } else {
        fb.classList.add('hidden');
    }
    document.getElementById('quiz-prev-btn').disabled = currentQIdx === 0;
}

function selectQuizAnswer(idx) {
    if (selectedAnswers[currentQIdx] !== undefined) return;
    selectedAnswers[currentQIdx] = idx;
    loadQuizQuestion();
}

function nextQuestion() {
    if (currentQIdx < activeQuizList.length - 1) {
        currentQIdx++;
        loadQuizQuestion();
    } else {
        finishQuiz();
    }
}

function prevQuestion() {
    if (currentQIdx > 0) {
        currentQIdx--;
        loadQuizQuestion();
    }
}

function finishQuiz() {
    const correctCount = quizCorrectCount();
    const score = Math.round((correctCount / activeQuizList.length) * 100);
    document.getElementById('quiz-content').classList.add('hidden');
    document.getElementById('quiz-result').classList.remove('hidden');
    document.getElementById('final-score').textContent = `${score} / 100 (${correctCount} / ${activeQuizList.length} düzgün)`;

    let badge = "Coğrafiya Həvəskarı";
    if (score === 100) badge = "Coğrafiya Eksperti 🏆";
    else if (score >= 60) badge = "Təcrübəli Mütəxəssis 📜";
    document.getElementById('result-badge-text').textContent = `Səviyyə: ${badge}`;
}

function resetQuiz() {
    shuffle(activeQuizList);
    currentQIdx = 0;
    quizScore = 0;
    selectedAnswers = [];
    document.getElementById('quiz-result').classList.add('hidden');
    document.getElementById('quiz-content').classList.remove('hidden');
    loadQuizQuestion();
}

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('quiz-options')) resetQuiz();
});
