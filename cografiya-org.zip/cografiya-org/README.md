# Coğrafiya.org - Coğrafiya Ailəsi Təhsil Portalı

Abituriyentlər, müəllimlər (MİQ/Sertifikasiya) və coğrafiya həvəskarları üçün statik təhsil portalı: sınaq imtahanları, interaktiv kalkulyatorlar, məqalələr və təhsil xəbərləri.

## Struktur

```
├── index.html        # Əsas səhifə
├── quizzes.html      # Sınaq imtahanları
├── tools.html        # İnteraktiv alətlər
├── articles.html     # Məqalələr
├── news.html         # Təhsil xəbərləri
├── contact.html      # Əlaqə
├── 404.html          # Tapılmadı səhifəsi
├── css/style.css     # Ümumi üslublar
└── js/
    ├── tailwind-config.js  # Tailwind rəng və şrift ayarları
    ├── main.js             # Menyu, ikonlar, modal (hamı səhifələr)
    ├── quiz.js             # Sınaq mühərriki
    ├── tools.js            # Kalkulyatorlar, region faktları
    ├── articles.js         # Məqalə axtarışı
    └── contact.js          # Əlaqə forması
```

## Lokal işə salmaq

Build tələb olunmur. Qovluqda sadə server başladın:

```bash
python3 -m http.server 8000
```

Sonra `http://localhost:8000` ünvanını açın.

## GitHub Pages ilə yayımlamaq

1. Repozitoriyanı GitHub-a yükləyin.
2. **Settings -> Pages -> Build and deployment** bölməsində *Deploy from a branch* seçin.
3. Branch olaraq `main`, qovluq olaraq `/ (root)` seçib saxlayın.
4. Bir neçə dəqiqədən sonra sayt `https://<istifadəçi>.github.io/<repo>/` ünvanında açılacaq.

## Qeydlər

- Tailwind CSS, Lucide ikonları və Inter şrifti CDN-dən yüklənir, internet bağlantısı lazımdır. Daha sürətli yükləmə üçün Tailwind-i build edilmiş CSS ilə əvəz etmək tövsiyə olunur.
- Əlaqə forması serverə göndərmir, istifadəçinin e-poçt proqramını doldurulmuş halda açır. Real göndərmə üçün Formspree, Netlify Forms və ya öz backend-iniz lazımdır.
- Xəbərlər və məqalələr hazırda HTML-də statik yazılıb.
